﻿using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.ComponentModel;
using VDS.RDF;
using VDS.RDF.Query;
using VDS.RDF.Parsing;
using VDS.RDF.Update;
using VDS.RDF.Update.Commands;
using VDS.RDF.Query.Patterns;
using VDS.RDF.Query.Datasets;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "there is three types of programs at ABC University";
        Label1.Visible = true;
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        TripleStore store = new TripleStore();
        store.Add(g1);
        //Assume that we fill our Store with data from somewhere

        //Create a dataset for our queries to operate over
        //We need to explicitly state our default graph or the unnamed graph is used
        //Alternatively you can set the second parameter to true to use the union of all graphs
        //as the default graph
        InMemoryDataset ds = new InMemoryDataset(store);

        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);

        //Use the SparqlQueryParser to give us a SparqlQuery object
        //Should get a Graph back from a CONSTRUCT query
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                                           prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                                                           prefix owl: <http://www.w3.org/2002/07/owl#>
                                                           SELECT   ?ProgramName 
                                                           WHERE {
                                                           ?t   owl:StudyingAtUniversity ?ProgramName 
                                                        }");
        Object results = processor.ProcessQuery(query);
        DataTable DT1 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT1 = FillDataTable(rset);
        GridView1.DataSource = DT1;
        GridView1.DataBind();
        GridView1.Visible = true;


        // to select Bachelor Programs
        Label2.Text = "Bachelor Programs at ABC University";
        Label2.Visible = true;
        SparqlQueryParser sparqlparser2 = new SparqlQueryParser();
        SparqlQuery query2 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                 prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                 prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT ?BachelorPrograms
                WHERE {
                ?t   owl:BachelorProgramAtUniversity ?BachelorPrograms
                }");
        Object results2 = processor.ProcessQuery(query2);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset2 = (SparqlResultSet)results2;
        DT2 = FillDataTable(rset2);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;

        // to select Master Programs
        Label3.Text = "Master Programs At ABC University";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT ?MasterPrograms 
                WHERE {
                ?t   owl:MasterProgramAtUniversity ?MasterPrograms 
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;

        // to select Training Programs
        Label4.Text = "Training Programs At ABC University";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?TrainingPrograms 
                WHERE {
                ?t   owl:TrainingProgramAtUniversity ?TrainingPrograms 
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = "there is three types of programs at ABC University";
        Label1.Visible = true;
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        TripleStore store = new TripleStore();
        store.Add(g1);
        //Assume that we fill our Store with data from somewhere

        //Create a dataset for our queries to operate over
        //We need to explicitly state our default graph or the unnamed graph is used
        //Alternatively you can set the second parameter to true to use the union of all graphs
        //as the default graph
        InMemoryDataset ds = new InMemoryDataset(store);

        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);

        //Use the SparqlQueryParser to give us a SparqlQuery object
        //Should get a Graph back from a CONSTRUCT query
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                                           prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                                                           prefix owl: <http://www.w3.org/2002/07/owl#>
                                                           SELECT   ?ProgramName 
                                                           WHERE {
                                                           ?t   owl:StudyingAtUniversity ?ProgramName 
                                                        }");
        Object results = processor.ProcessQuery(query);
        DataTable DT1 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT1 = FillDataTable(rset);
        GridView1.DataSource = DT1;
        GridView1.DataBind();
        GridView1.Visible = true;
        // to select Bachelor Programs
        Label2.Text = "Bachelor Programs at ABC University";
        Label2.Visible = true;
        SparqlQueryParser sparqlparser2 = new SparqlQueryParser();
        SparqlQuery query2 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                                            prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                                                            prefix owl: <http://www.w3.org/2002/07/owl#>
                                                            SELECT ?BachelorPrograms
                                                            WHERE {
                                                            ?t   owl:BachelorProgramAtUniversity ?BachelorPrograms
                                                          }");
        Object results2 = processor.ProcessQuery(query2);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset2 = (SparqlResultSet)results2;
        DT2 = FillDataTable(rset2);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;

        // to select Master Programs
        Label3.Text = "Master Programs At ABC University";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT ?MasterPrograms 
                WHERE {
                ?t   owl:MasterProgramAtUniversity ?MasterPrograms 
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;

        // to select Training Programs
        Label4.Text = "Training Programs At ABC University";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?TrainingPrograms 
                WHERE {
                ?t   owl:TrainingProgramAtUniversity ?TrainingPrograms 
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }

    protected void Button2_Click1(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        Label1.Text = "Biotechnology Program Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        //Use the SparqlQueryParser to give us a SparqlQuery object
        //Should get a Graph back from a CONSTRUCT query
        Label2.Text = "Biotechnology Director Informations ";
        Label2.Visible = true;
        // to select the Biotechnology Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                SELECT   ?BiotechnologyDirectorInfo 
                WHERE {
                ?t   owl:BiotechnologyDirectorInfoProperty ?BiotechnologyDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers Biotechnology program
        Label3.Text = "Teachers Of Biotechnology Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser2 = new SparqlQueryParser();
        SparqlQuery query2 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?TeachersBiotechnology 
                WHERE {
                ?t   owl:TeachersOfBiotechnology ?TeachersBiotechnology 
                }");
        Object results2 = processor.ProcessQuery(query2);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset5 = (SparqlResultSet)results2;
        DT3 = FillDataTable(rset5);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Biotechnology
        Label4.Text = "Courses of Biotechnology Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesBiotechnology 
                WHERE {
                ?t   owl:CoursesOfBiotechnology ?CoursesBiotechnology 
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset6 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset6);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Information Technology Program ITE Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Information Technology Program Director Infomation ";
        Label2.Visible = true;
        // to select the Information Technology Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?ITDirectorInfo
                WHERE {
                ?t   owl:ITDirectorInfoProperty ?ITDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers Information Technology program
        Label3.Text = "Teachers Of Information Technology Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?ITTeachers 
                WHERE {
                ?t   owl:TeachersOfIT ?ITTeachers 
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);    
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Information Technology
        Label4.Text = "Courses of Information Technology Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?ITCourses 
                WHERE {
                ?t   owl:CoursesOfIT ?ITCourses 
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);    
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Cybersecurity Program : BL Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Cybersecurity Informations ";
        Label2.Visible = true;
        // to select the Cybersecurity Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CybersecurityDirectorInformation
                WHERE {
                ?t   owl:CybersecurityDirectorInfoProperty ?CybersecurityDirectorInformation
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers Cybersecurity program
        Label3.Text = "Teachers Of Cybersecurity Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CybersecurityTeachers
                WHERE {
                ?t   owl:TeachersOfCybersecurity ?CybersecurityTeachers 
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Cybersecurity
        Label4.Text = "Courses of Cybersecurity Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CybersecurityCourses
                WHERE {
                ?t   owl:CoursesOfCybersecurity ?CybersecurityCourses
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);    
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;    
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Master in Web Security Program : WebSec Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Web Security Program Informations ";
        Label2.Visible = true;
        // to select the Web Security Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?WebSecDirectorInfo 
                WHERE {
                ?t   owl:WebSecDirectorInfoProperty ?WebSecDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of WebSec program
        Label3.Text = "Teachers Of Master in Web Security Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?WebSecTeachers
                WHERE {
                ?t   owl:TeachersOfWebSec ?WebSecTeachers 
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Master in Web Security
        Label4.Text = "Courses of Master in Web Security Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?WebSecCourses
                WHERE {
                ?t   owl:CoursesOfWebSec ?WebSecCourses
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);     
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Master in Web Technology Program : Webtech Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Web Technology Program Informations ";
        Label2.Visible = true;
        // to select the Web Technology Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?WebtechDirectorInfo 
                WHERE {
                ?t   owl:WebtechDirectorInfoProperty ?WebtechDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Webtech program
        Label3.Text = "Teachers Of Webtech Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?WebtechTeachers
                WHERE {
                ?t   owl:TeachersOfWebtech ?WebtechTeachers
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Webtech
        Label4.Text = "Courses of Web Technology Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesWebtech
                WHERE {
                ?t   owl:CoursesOfWebtech ?CoursesWebtech
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Master in Technology Management Program : MAT Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Master in Technology Management Program Informations ";
        Label2.Visible = true;
        // to select the Master in Technology Management Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?MATDirectorInformatios 
                WHERE {
                ?t   owl:MATDirectorInfoProperty ?MATDirectorInformatios 
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Master in Technology Management program
        Label3.Text = "Teachers Of Master in Technology Management Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?MATTeachers
                WHERE {
                ?t   owl:TeachersOfMAT ?MATTeachers
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Master in Technology Management
        Label4.Text = "Courses of Master in Technology Management Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesMAT
                WHERE {
                ?t   owl:CoursesOfMAT ?CoursesMAT
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Master In Quality Management Program : QUALMAN Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Master in Quality Management Program Informations ";
        Label2.Visible = true;
        // to select the Master in Quality Management Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?QUALMANDirectorInfo 
                WHERE {
                ?t   owl:QUALMANDirectorInfoProperty ?QUALMANDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Master in Quality Management program
        Label3.Text = "Teachers Of Master in Quality Management Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?QUALMANTeachers
                WHERE {
                ?t   owl:TeachersOfQUALMAN ?QUALMANTeachers
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Master in Quality Management
        Label4.Text = "Courses of Master in Quality Management Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesQUALMAN
                WHERE {
                ?t   owl:CoursesOfQUALMAN ?CoursesQUALMAN
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Master in Business Administration Program : MBA Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Master in Business Administration Program Informations ";
        Label2.Visible = true;
        // to select the Master in Business Administration Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?MBADirectorInfo 
                WHERE {
                ?t   owl:MBADirectorInfoProperty ?MBADirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Master in Business Administration program
        Label3.Text = "Teachers Of Master in Business Administration Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?MBATeachers
                WHERE {
                ?t   owl:TeachersOfMBA ?MBATeachers
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Master in Business Administration
        Label4.Text = "Courses of Master in Business Administration Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesMBA
                WHERE {
                ?t   owl:CoursesOfMBA ?CoursesMBA
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        //Bachelor in Journalism Communications Technology Program Details
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Bachelor in Journalism Communications Technology Program : BMC Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Bachelor in Journalism Communications Technology Program Director Informations ";
        Label2.Visible = true;
        // to select the Communications Technology program's Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?JournalismCommunicationDirectorInfo
                WHERE {
                ?t   owl:JournalismCommunicationDirectorInfoProperty ?JournalismCommunicationDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Bachelor in Journalism Communications Technology program
        Label3.Text = "Teachers Of Bachelor in Journalism Communications Technology Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?TeachersOfJournalismCommunicationProgram
                WHERE {
                ?t   owl:TeachersOfJournalismCommunication ?TeachersOfJournalismCommunicationProgram
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Bachelor in Communications Technology
        Label4.Text = "Courses of Bachelor in Journalism Communications Technology Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?CoursesBMC
                WHERE {
                ?t   owl:CoursesOfJournalismCommunication ?CoursesBMC
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        //Bachelor in Communications Technology Program Details
        TripleStore store = new TripleStore();
        Graph g1 = new Graph();
        g1.LoadFromFile(Server.MapPath("universityinfo.rdf"));
        store.Add(g1);
        InMemoryDataset ds = new InMemoryDataset(store);
        //Get the Query processor
        ISparqlQueryProcessor processor = new LeviathanQueryProcessor(ds);
        Label1.Text = "Bachelor in Communications Technology Program : BACT Details";
        Label1.Visible = true;
        GridView1.Visible = false;
        Label2.Text = "Bachelor in Communications Technology Program Informations ";
        Label2.Visible = true;
        // to select the Communications Technology program's Director Informations 
        SparqlQueryParser sparqlparser = new SparqlQueryParser();
        SparqlQuery query = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                SELECT   ?BACTDirectorInfo
                WHERE {
                ?t   owl:CommunicationtechDirectorInfoProperty ?BACTDirectorInfo
                }");
        Object results = processor.ProcessQuery(query);
        DataTable DT2 = new DataTable();
        SparqlResultSet rset = (SparqlResultSet)results;
        DT2 = FillDataTable(rset);
        GridView2.DataSource = DT2;
        GridView2.DataBind();
        GridView2.Visible = true;
        //to retrival the Teachers of Bachelor in Communications Technology program
        Label3.Text = "Teachers Of Bachelor in Communications Technology Program";
        Label3.Visible = true;
        SparqlQueryParser sparqlparser3 = new SparqlQueryParser();
        SparqlQuery query3 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix foaf: <http://xmlns.com/foaf/0.1/#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?BACTTeachers
                WHERE {
                ?t   owl:TeachersOfTelecommunicationsTechnology ?BACTTeachers
                }");
        Object results3 = processor.ProcessQuery(query3);
        DataTable DT3 = new DataTable();
        SparqlResultSet rset3 = (SparqlResultSet)results3;
        DT3 = FillDataTable(rset3);     
        GridView3.DataSource = DT3;
        GridView3.DataBind();
        GridView3.Visible = true;
        //to select Courses Of Bachelor in Communications Technology
        Label4.Text = "Courses of Bachelor in Communications Technology Program";
        Label4.Visible = true;
        SparqlQueryParser sparqlparser4 = new SparqlQueryParser();
        SparqlQuery query4 = sparqlparser.ParseFromString(@"prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                prefix owl: <http://www.w3.org/2002/07/owl#>
                SELECT   ?BACTCourses
                WHERE {
                ?t   owl:Communicationtech ?BACTCourses
                }");
        Object results4 = processor.ProcessQuery(query4);
        DataTable DT4 = new DataTable();
        SparqlResultSet rset4 = (SparqlResultSet)results4;
        DT4 = FillDataTable(rset4);
        GridView4.DataSource = DT4;
        GridView4.DataBind();
        GridView4.Visible = true;
    }
    public static DataTable FillDataTable(SparqlResultSet Results)
    {
        SparqlResult resultt = new SparqlResult();
        DataTable DT = new DataTable();
        if (Results.Results.Count > 0)
        {
            resultt = Results.Results[0];
            for (int i = 0; i < resultt.Variables.ToList().Count; i++)
                DT.Columns.Add(resultt.Variables.ToList()[i], typeof(String));
        }
        foreach (SparqlResult result in Results)
        {
            DataRow DR = DT.NewRow();
            for (int i = 0; i < result.Count; i++)
            {
                if (result[i] == null)
                    DR[i] = "";
                else if (result[i].NodeType == NodeType.Uri)
                    DR[i] = ((UriNode)result[i]).Uri;
                else if (result[i].NodeType == NodeType.Blank)
                    DR[i] = ((BlankNode)result[i]).InternalID.ToString();
                else if (result[i].NodeType == NodeType.Literal)
                    DR[i] = ((LiteralNode)result[i]).Value.ToString();
            }
            DT.Rows.Add(DR);
        }
        return (DT);
    }
    
}